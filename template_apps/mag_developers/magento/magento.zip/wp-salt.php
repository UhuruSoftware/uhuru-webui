<?php
define('AUTH_KEY',         'u+Q(gpz!Mz+H7*s0}f-DCc{:|($6gI shn/i:, [V~bk9~|oKj$vHj5N}|9wD![$');
define('SECURE_AUTH_KEY',  'Uk*;.?7q;1olLX1&+o1nTl-qab$LX$aUI&afWaBH.:zyKvv5!^5t1+iPqW<M81@-');
define('LOGGED_IN_KEY',    'MEk*v+Ml;U;bf1,_Y@P[:5.=OL=pq6Bh4.?H;_o756uB9%QJ(>UfN>MJ|H$$CS6%');
define('NONCE_KEY',        'Yt(f+l{3YHx#TUBqA:h-5ed9yiTDe!u#~8S~(6#P~);~0p,FiZ_L|V)@wb;$a9~J');
define('AUTH_SALT',        'j-1x+&^?8@I7p}|#=ji[pY[VR?PPa:yrg*o~|`<Q5rao`CDx}u-nC@-vb_G&Wp?x');
define('SECURE_AUTH_SALT', 'C7W+W?Uv+W9TzPY`^a#X,.^]#QI(4k9%1?YUlr:+Nh`~7uRpI1Kbl7*JAoMEwz:j');
define('LOGGED_IN_SALT',   '<n {S%$?B !xA&oB^3G)fwdlTR7${s1wXMn.Ru[CyoVNaZJX~U[<kxv=ftM}i$p7');
define('NONCE_SALT',       'AY*L7pi7WBDw;f:D,U_lnWuZKwg<5=,+kU88b]CHPRfL wvY,u!8Y:2a8+8WAnil');